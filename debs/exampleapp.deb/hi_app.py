import tkinter as tk

class HiApp:
    def __init__(self, root):
        self.root = root
        root.title("Hi App")
        
        label = tk.Label(root, text="Hi", font=("Helvetica", 24))
        label.pack(padx=20, pady=20)

if __name__ == "__main__":
    root = tk.Tk()
    app = HiApp(root)
    root.mainloop()
